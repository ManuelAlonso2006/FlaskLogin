import sqlite3

def verificar_usuario(name, password):
    conexion = sqlite3.connect("usuarios.db")
    cursor = conexion.cursor()
    cursor.execute("SELECT * FROM users WHERE name = ? AND password = ?", (name, password))
    resultado = cursor.fetchone()
    conexion.close()
    if resultado != None:
        return f"Bienvenido {name}"
    else:
        return "Usuario o Contraseña incorrecto"
    
user = verificar_usuario('manuel', '123')
print(user)